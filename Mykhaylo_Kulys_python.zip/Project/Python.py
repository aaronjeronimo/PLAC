import tkinter as tk
from tkinter import ttk, font
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import sqlite3

conn = sqlite3.connect('hotel_data.db')
cursor = conn.cursor()

#read the database
file = pd.read_csv(r'C:\Users\migui\Documents\Compiladores\archive\hotel_booking.csv')

#Functions
def average_nights():
    #average nights
    avg_nights = file.groupby('hotel').agg({
        'stays_in_weekend_nights': 'mean',
        'stays_in_week_nights': 'mean'
    }).reset_index()
    avg_nights['average_nights'] = avg_nights['stays_in_weekend_nights'] + avg_nights['stays_in_week_nights']
    avg_nights = avg_nights[['hotel', 'average_nights']]

    avg_nights_all = file.groupby('hotel')[['stays_in_weekend_nights', 'stays_in_week_nights']].mean().reset_index()
    avg_nights_all['average_nights'] = avg_nights_all['stays_in_weekend_nights'] + avg_nights_all['stays_in_week_nights']
    avg_nights_all['hotel'] = 'ALL HOTELS'

    avg_nights_comb = pd.concat([avg_nights, avg_nights_all], ignore_index=True)
    #Save in the database
    avg_nights_comb.to_sql('average_nights', conn, if_exists= 'replace', index= False)
    #To csv
    avg_nights_comb.to_csv('average_nights.csv', index=False)
    #Plot
    plt.figure(figsize=(10, 6))
    sns.barplot(x='hotel', y='average_nights', data=avg_nights_comb)
    plt.title('Average Number of Nights')
    plt.xlabel('Hotel')
    plt.ylabel('Average Nights')
    plt.grid(True)
    plt.tight_layout()
    plt.show()


def cancel_rate():
    #cancel rate
    cancel_rate = file.groupby('hotel')['is_canceled'].mean().reset_index()
    cancel_rate['is_canceled'] *= 100
    cancel_rate_all = pd.DataFrame({
        'hotel': ['ALL HOTELS'],
        'is_canceled': [file['is_canceled'].mean()]
    })
    cancel_rate_all['is_canceled'] *= 100
    cancel_rate_comb = pd.concat([cancel_rate, cancel_rate_all], ignore_index=True)
    
    #save in database
    cancel_rate_comb.to_sql('cancel_rate', conn, if_exists='replace', index=False)
    #To csv
    cancel_rate_comb.to_csv('cancelation_rate.csv', index=False)

    #Plot
    plt.figure(figsize=(10, 6))
    sns.barplot(x='hotel', y='is_canceled', data=cancel_rate_comb)
    plt.title('Cancellation Rate')
    plt.xlabel('Hotel')
    plt.ylabel('Cancellation Rate (%)')
    plt.grid(True)
    plt.tight_layout()
    plt.show()

#order the months
ordered_months = ['January', 'February', 'March', 'April', 'May', 'June', 
                  'July', 'August', 'September', 'October', 'November', 'December']

def season_distribution():
    #distribution by month and season
    monthly_season_dist = file.groupby(['arrival_date_month', 'arrival_date_year', 'hotel']).size().reset_index(name='monthly_distribution')
    monthly_season_dist['arrival_date_month'] = pd.Categorical(monthly_season_dist['arrival_date_month'], categories=ordered_months, ordered=True)
    monthly_season_dist = monthly_season_dist.sort_values(by='arrival_date_month')
    #save in database
    for _, row in monthly_season_dist.iterrows():
        cursor.execute('''INSERT INTO season_distribution (arrival_date_month, arrival_date_year, monthly_distribution) VALUES (?, ?, ?)''', (row['arrival_date_month'], row['arrival_date_year'], row['monthly_distribution']))
    conn.commit()
    #To csv
    monthly_season_dist.to_csv('season_distribution.csv', index=False)

    #Plot
    plt.figure(figsize=(10, 6))
    sns.lineplot(data=monthly_season_dist, x='arrival_date_month', y='monthly_distribution', hue='arrival_date_year', marker='o', palette='Set1',errorbar=None)
    plt.title('Distribution by Month and Season')
    plt.xlabel('Month')
    plt.ylabel('Number of Bookings')
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    

def room_type():
    #distribution of booking by room type
    room_type = file['reserved_room_type'].value_counts().reset_index()
    room_type.columns = ['room_type', 'count']
    #save in database
    for _, row in room_type.iterrows():
        cursor.execute('''INSERT INTO room_type_distribution (room_type, count) VALUES (?, ?)''', (row['room_type'], row['count']))
    conn.commit()
    #To csv
    room_type.to_csv('rooom_type.csv', index=False)

    #Plot
    plt.figure(figsize=(8, 6))
    plt.bar(room_type['room_type'], room_type['count'])
    plt.title('Distribution of Booking by Room Type')
    plt.xlabel('Room Type')
    plt.ylabel('Count')
    plt.xticks(rotation=0)
    plt.grid(axis='y')
    plt.tight_layout()
    plt.show()

    
def traveler_type():
    #bookings for families couples or individual travelers
    traveler_counts = file[['adults', 'children', 'babies']].copy()
    traveler_counts['traveler_type'] = ''
    #Clasify
    for i, row in traveler_counts.iterrows():
        if row['adults'] > 0 and row['children'] > 0:
            traveler_counts.at[i, 'traveler_type'] = 'Family'
        elif row['adults'] == 2 and row['children'] == 0:
            traveler_counts.at[i, 'traveler_type'] = 'Couple'
        else:
            traveler_counts.at[i, 'traveler_type'] = 'Individual'

    traveler_type = traveler_counts['traveler_type'].value_counts().reset_index()
    traveler_type.columns = ['traveler_type', 'count']
    #save in database
    for _, row in traveler_type.iterrows():
        cursor.execute('''INSERT INTO traveler_type_distribution (traveler_type, count) VALUES (?, ?)''', (row['traveler_type'], row['count']))
    conn.commit()
    #To csv
    traveler_type.to_csv('traveler_type.csv', index=False)

    #Plot
    plt.figure(figsize=(8, 6))
    sns.barplot(x='traveler_type', y='count', data=traveler_type, palette='Set3')
    plt.title('Traveler Type Distribution')
    plt.xlabel('Traveler Type')
    plt.ylabel('Count')
    plt.grid(axis='y')
    plt.tight_layout()
    plt.show()
    

def booking_trends():
    #booking trends over time
    monthly_season_dist = file.groupby(['arrival_date_month', 'arrival_date_year', 'hotel']).size().reset_index(name='monthly_distribution')
    trend_time = monthly_season_dist.groupby(['arrival_date_year', 'arrival_date_month'])['monthly_distribution'].sum().reset_index()
    trend_time['arrival_date_month'] = pd.Categorical(trend_time['arrival_date_month'], categories=ordered_months, ordered=True)
    trend_time = trend_time.sort_values(['arrival_date_year', 'arrival_date_month'])
    #save in database
    for _, row in trend_time.iterrows():
        cursor.execute('''INSERT INTO booking_trends (arrival_date_year, arrival_date_month, monthly_distribution) VALUES (?, ?, ?)''', (row['arrival_date_year'], row['arrival_date_month'], row['monthly_distribution']))
    conn.commit()
    #To csv
    trend_time.to_csv('trend_time.csv', index=False)

    #Plot
    plt.plot(trend_time['arrival_date_year'].astype(str) + '-' + trend_time['arrival_date_month'].astype(str).str.zfill(2), trend_time['monthly_distribution'], marker='o')
    plt.title('Booking Trends Over Time')
    plt.xlabel('Year-Month')
    plt.ylabel('Number of Bookings')
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()
    plt.show()




def trends_booking_cancellation():
    #trends in booking or cancellation
    season_data = file.groupby(['arrival_date_year', 'arrival_date_month', 'hotel', 'is_canceled']).size().reset_index(name='count')
    season_data['arrival_date_month'] = pd.Categorical(season_data['arrival_date_month'], categories=ordered_months, ordered=True)
    season_data = season_data.sort_values(['arrival_date_year', 'arrival_date_month'])
    canceled_data = season_data[season_data['is_canceled'] == 1]
    reservation_data = season_data[season_data['is_canceled'] == 0]
    fig, axs = plt.subplots(2, 1, figsize=(15, 10), sharex=True)
    for _, row in season_data.iterrows():
        cursor.execute('''INSERT INTO booking_cancellation_trends (arrival_date_year, arrival_date_month, hotel, count, is_canceled) VALUES (?, ?, ?, ?, ?)''', 
                       (row['arrival_date_year'], row['arrival_date_month'], row['hotel'], row['count'], row['is_canceled']))
    conn.commit()
    #To csv
    season_data.to_csv('season_data.csv', index=False)

    #Plot bookings
    for hotel in reservation_data['hotel'].unique():
        hotel_data = reservation_data[(reservation_data['hotel'] == hotel)]
        bookings_by_month = hotel_data.groupby(['arrival_date_year', 'arrival_date_month'])['count'].sum().reset_index()
        axs[0].plot(bookings_by_month['arrival_date_year'].astype(str) + '-' + bookings_by_month['arrival_date_month'].astype(str), bookings_by_month['count'], label=hotel)

    axs[0].set_title('Bookings by hotel')
    axs[0].set_ylabel('Quantity')
    axs[0].legend()

    #Plot Cancelations
    for hotel in canceled_data['hotel'].unique():
        hotel_data = canceled_data[(canceled_data['hotel'] == hotel)]
        canceled_by_month = hotel_data.groupby(['arrival_date_year', 'arrival_date_month'])['count'].sum().reset_index()
        axs[1].plot(canceled_by_month['arrival_date_year'].astype(str) + '-' + canceled_by_month['arrival_date_month'].astype(str), canceled_by_month['count'], label=hotel)

    axs[1].set_title('Cancellations by hotel')
    axs[1].set_xlabel('Year-month')
    axs[1].set_ylabel('Quantity')
    axs[1].legend()

    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    


#GUI
root = tk.Tk()
root.title("Hotel Analisys")

frame = ttk.Frame(root, padding=(20, 10))
frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

#Buttons
btn_avg_nights = ttk.Button(frame, text="Average Nights", command=average_nights)
btn_avg_nights.grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)

btn_cancel_rate = ttk.Button(frame, text="Cancellation Rate", command=cancel_rate)
btn_cancel_rate.grid(row=0, column=1, padx=10, pady=10, sticky=tk.W)

btn_booking_trends = ttk.Button(frame, text="Booking Trends", command=booking_trends)
btn_booking_trends.grid(row=0, column=2, padx=10, pady=10, sticky=tk.W)

btn_season_distribution = ttk.Button(frame, text="Season Distribution", command=season_distribution)
btn_season_distribution.grid(row=1, column=0, padx=10, pady=10, sticky=tk.W)

btn_room_type = ttk.Button(frame, text="Room Type Distribution", command=room_type)
btn_room_type.grid(row=1, column=1, padx=10, pady=10)

btn_traveler_type = ttk.Button(frame, text="Traveler Type Distribution", command=traveler_type)
btn_traveler_type.grid(row=1, column=2, padx=10, pady=10)

btn_trends_booking_cancelation = ttk.Button(frame, text="Trends Booking/Cancelation", command=trends_booking_cancellation)
btn_trends_booking_cancelation.grid(row=2, column=0, padx=10, pady=10, columnspan=3, sticky=tk.W)


root.mainloop()